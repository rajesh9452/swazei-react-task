<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        // Query only non-soft-deleted products
        $query = Product::query();

        // Apply search filter based on product name
        if ($request->has('search') && !empty($request->input('search'))) {
            $search = $request->input('search');
            $query->where('name','LIKE',"%{$search}%");
        }
        $perPage = $request->input('per_page', 12); // Default to 10 products per page
        $products = $query->whereNull('deleted_at')->paginate($perPage);

        if(count($products) > 0){
            return response()->json([
                'resCode'=>1,
                'products' => $products
            ]);
        }else{
            return response()->json([
                'resCode'=>0,
                'message' => 'Data not found'
            ]);
        }
       
    }
    public function destroy($id)
        {
            $product = Product::find($id);
            if (!$product) {
                return response()->json(['resCode'=>0,'message' => 'Product not found'], 404);
            }
            $product->delete();
            return response()->json(['resCode'=>1,'message' => 'Product deleted successfully'], 200);
        }
}
