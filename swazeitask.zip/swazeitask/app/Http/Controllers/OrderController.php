<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;


class OrderController extends Controller
{
    public function placeOrder(Request $request)
    {
        // Get the authenticated user using Sanctum
        $productId = $request->input('productId');
        $user = $request->user();
        $product = Product::find($productId);
        if(!$product){
            return response()->json(['resCode'=>0,'message' => 'Product not found'], 404);
        }
        // // Calculate total amount
        // Create the order
        $order = Order::create([
            'user_id' => $user->id,
            'total_amount' => $product->price,
            'status' => 'pending',
            'shipping_address' => 'Testing',
            'payment_status' => 'unpaid',
        ]);
        OrderItem::create([
            'order_id' => $order->id,
            'product_id' => $product->id,
            'quantity' => 1,
            'price' =>$product->price,
        ]);
        // // Return the order details
        return response()->json([
            'resCode'=>1,
            'message' => 'Order placed successfully',
            'order' => $order,
        ], 201);
    }
    public function getUserOrders(Request $request){
            // Get the authenticated user
            $user = $request->user();
            $orders = Order::with(['items.product'])->where('user_id',$user->id)->get();
            return response()->json(['resCode'=>0,'orders' => $orders]);
    }
}