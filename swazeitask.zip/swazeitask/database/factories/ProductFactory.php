<?php
namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Http\UploadedFile;
use Faker\Generator as Faker;

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            // Generate a fake image URL using faker's image method
            'imagesUrl' => $this->faker->imageUrl(640, 480, 'product', true, 'avatar.jpg'),
            'description' => $this->faker->text,
            'price' => $this->faker->randomFloat(2, 1, 100),
        ];
    }
}

